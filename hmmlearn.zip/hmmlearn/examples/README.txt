.. _examples:

Examples
========
